document.write("<script type='text/javascript' src='http://mbostock.github.com/d3/d3.js?1.27.2'></script>");
document.write("<link rel='stylesheet' type='text/css' href='../style.css'>");
document.write("<script src='../main.js'></script>");
